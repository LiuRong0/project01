package model;

import com.alibaba.fastjson.JSONObject;
import util.DBUtil;

import javax.servlet.ServletException;
import java.sql.*;

public class User {
    //private static final Object User = ;
    public Integer uid;
    public String username;
    public String nickname;
    public String password;

    public User(){

    }
    public User(Integer uid, String nickname) {
        this.uid = uid;
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", username='" + username + '\'' +
                ", nickname='" + nickname + '\'' +
                '}';
    }

    public static class JSONUtil implements JSONSerializable<User> {
        @Override
        public JSONObject toJSON(User model) {
            JSONObject object = new JSONObject();
            if (model.uid != null) {
                object.put("uid", model.uid);
            }
            if (model.username != null) {
                object.put("username", model.username);
            }
            if (model.nickname != null) {
                object.put("nickname", model.nickname);
            }
            return object;
        }

        @Override
        public User fromJSON(JSONObject object) {
            User model = new User();

            if (object.containsKey("uid")) {
                model.uid = object.getInteger("uid");
            }
            if (object.containsKey("nickname")) {
                model.nickname = object.getString("nickname");
            }
            if (object.containsKey("username")) {
                model.username = object.getString("username");
            }

            return model;
        }
    }
    public static final JSONUtil jsonUtil = new JSONUtil();


    public static boolean insert(String username,String nickname, String password) throws ServletException {


        // 2. 利用 JDBC 保存 MySQL
        try (Connection connection = DBUtil.getConnection()) {
            String sql = "INSERT INTO users (username,nickname, password) VALUES (?, ?,?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, username);
                stmt.setString(2, nickname);
                stmt.setString(3, password);

                stmt.executeUpdate();
                // 插入成功

                // 3. id 是自增主键，所以，利用 JDBC 的方法取出 id
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        int uid = rs.getInt(1);

                        // 4. 返回构建好的用户对象
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        // 如果插入过程中，出现问题，返回 null
        return false;
    }


}
