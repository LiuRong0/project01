package dao;

import java.sql.*;

import model.User;
import util.DBUtil;

import static util.DBUtil.getConnection;

/**
 * 用户数据库操作类
 */
public class UserDao {

    public String findUsername(String username){
        String psw = null;
        Connection con =null;
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        try {
            String driver ="com.mysql.cj.jdbc.Driver";
            String url ="jdbc:mysql://localhost:3306/survey?useSSL=false&serverTimezone=GMT%2B8";
            String user ="root";
            String password =" ";//改为自己的用户名密码和数据库名
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, password);
            String sql = "select * from users where username=?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();
            if(rs==null){
                return null;
            }
            if(rs.next()){
                psw=rs.getString("password");
            }else{
                psw=null;
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(pstmt!=null)pstmt.close();
                if(con!=null)con.close();
            }
            catch (SQLException e) {
            }
        }
        return psw;
    }

}
