package servlet;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import dao.UserDao;
import model.User;
import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.IOException;
import java.sql.*;

import static java.lang.Class.forName;
import static util.DBUtil.getConnection;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    String  pws = null;
    private static String result = null;
    private static String account = null;
    private static String nickname02 = null;
    private static String password02 = null;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. 获取用户输入
        req.setCharacterEncoding("utf-8");
        String uid = req.getParameter("uid");
        String username1 = req.getParameter("username");
        String password1= req.getParameter("password");
        String psw ;
        //2.连接数据库进行查询
        req.setCharacterEncoding("utf-8");

        // 2. TODO: 合法性校验
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT uid,username,nickname,password FROM users WHERE password = ?";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                //stmt.setString(1, username);
                stmt.setString(1, password1);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        result = rs.getString(1);
                         account = rs.getString(2);
                         nickname02 = rs.getString(3);
                         password02 = rs.getString(4);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        }

        // 3. 从 MySQL 中查询登录的用户
        //int flag = User.getByUsernameAndPassword(username, password);
        if (result!=null&&account!=null&&password1!=null&&nickname02!=null&&password1.equals(password02)) {
            // 给出提示 OR 302 到 /login.html
            resp.sendRedirect("/editor.html");
            return;
        }else{
            resp.sendRedirect("/index.html");
        }

        /*// 4. 写入 Session 中，表示登录成功
        HttpSession session = req.getSession();
        session.setAttribute("username", username1);
*/
        // 5. 登录成功，跳转到文章发表页面



    }


}

